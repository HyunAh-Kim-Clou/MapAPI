package kr.rndns.browseexhibition

import android.content.Context
import android.util.Log

class BridgeOfExhDB {
    var exhDB: ExhDatabase
    constructor(context: Context) {
        exhDB = ExhDatabase.getInstance(context)!!
    }

    fun insertExhFacs(exhfacs: ArrayList<TmpExhFac>) {
        Log.d("BE10001", ""+exhDB?.isOpen())
        Log.d("BE10001", ""+exhfacs.isEmpty())
        exhfacs.forEach {
            exhDB?.ExhFacilityDao()?.insert(
                ExhFacility(it.no, it.facname, it.addr, it.x, it.y, it.homepage))
        }
    }
    fun getExhFacList(): List<ExhFacility> {
        return exhDB?.ExhFacilityDao()?.getAll()
    }

    class TmpExhFac constructor(
            var no: Int,
            var facname:String,
            var addr: String,
            var x: Double,
            var y: Double,
            var homepage: String) {
        fun show(): String {
            return "$no $facname $addr $x $y $homepage"
        }
    }
}