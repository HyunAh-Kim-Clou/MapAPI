package kr.rndns.browseexhibition

import android.content.Intent
import android.os.Bundle
import android.os.PersistableBundle
import android.util.Log
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity: AppCompatActivity() {
    lateinit var checkDB: Button
    lateinit var removeDB: Button
    lateinit var showGoogleMap: Button
    var db: ExhDatabase? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.layout_main)

        checkDB = findViewById(R.id.checkDB)
        removeDB = findViewById(R.id.removeDB)
        showGoogleMap = findViewById(R.id.showGoogleMap)

        db = ExhDatabase.getInstance(this)
        Log.d("MA10001", ""+this)

        checkDB.setOnClickListener {
            Log.d("MA10001", ""+ (db?.isOpen))
            val intent: Intent = Intent(this, getWebAPI::class.java)
            startActivity(intent)
        }
        removeDB.setOnClickListener {
            Log.d("MA10001", ""+db)
            ExhDatabase.destoryInstance()
        }
        showGoogleMap.setOnClickListener {
            val intent: Intent = Intent(this, MapsActivity::class.java)
            startActivity(intent)
        }
    }
}