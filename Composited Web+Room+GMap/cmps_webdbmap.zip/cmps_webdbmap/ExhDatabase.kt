package kr.rndns.browseexhibition

import android.content.Context
import androidx.room.*

@Entity(tableName = "ExhFacility")
data class ExhFacility (
    @PrimaryKey(autoGenerate = true) var no: Int,
    @ColumnInfo(name = "facName") var facName: String,
    @ColumnInfo(name = "addr") var addr: String,
    @ColumnInfo(name = "xCoord") var xCoord: Double,
    @ColumnInfo(name = "yCoord") var yCoord: Double,
    @ColumnInfo(name = "homepage") var homepage: String
)
@Entity(tableName = "Exhibition")
data class Exhibition(
    @PrimaryKey(autoGenerate = true) var no: Int,
    @ColumnInfo(name = "exhName") var exhName: String,
    @ColumnInfo(name = "period") var period: String,
    @ColumnInfo(name = "website") var website: String,
    @ColumnInfo(name = "fees") var fees: String,
    @ColumnInfo(name = "closeDay") var closeDay: String,
    @ColumnInfo(name = "operHours") var operHours: String
)
@Entity(tableName = "UserOperated")
data class UserOperated(
    @PrimaryKey(autoGenerate = true) var no: Int,
    @ColumnInfo(name = "userName") var userName: String,
    @ColumnInfo(name = "exhGoing") var exhGoing: String,
    @ColumnInfo(name = "facFavor") var facFavor: String
)

@Dao
interface ExhFacilityDao {
    @Query("SELECT * FROM ExhFacility")
    fun getAll(): List<ExhFacility>
    @Insert
    fun insert(obj: ExhFacility)
    @Update
    fun update(obj: ExhFacility)
    @Delete
    fun delete(obj: ExhFacility)
}
@Dao
interface ExhibitionDao {
    @Query("SELECT * FROM Exhibition")
    fun getAll(): List<Exhibition>
    @Insert
    fun insert(obj: Exhibition)
    @Update
    fun update(obj: Exhibition)
    @Delete
    fun delete(obj: Exhibition)
}
@Dao
interface UserOperatedDao {
    @Query("SELECT * FROM UserOperated")
    fun getAll(): List<UserOperated>
    @Insert
    fun insert(obj: UserOperated)
    @Update
    fun update(obj: UserOperated)
    @Delete
    fun delete(obj: UserOperated)
}

// ExhDatabase
//   ExhFacility
//   Exhibition
//   UserOperated
@Database(entities = arrayOf(ExhFacility::class, Exhibition::class, UserOperated::class), version = 1)
abstract class ExhDatabase: RoomDatabase() {
    abstract fun ExhFacilityDao(): ExhFacilityDao
    abstract fun ExhibitionDao(): ExhibitionDao
    abstract fun UserOperatedDao(): UserOperatedDao

    companion object {
        private var INSTANCE: ExhDatabase? = null

        fun getInstance(context: Context): ExhDatabase? {
            if (INSTANCE == null) {
                synchronized(ExhDatabase::class) {
                    INSTANCE = Room.databaseBuilder(context.applicationContext,
                        ExhDatabase::class.java, "rndns_exhibitbrowse.db")
                        .allowMainThreadQueries()
                        .build()
                }
            }
            return INSTANCE
        }

        fun destoryInstance() {
            INSTANCE = null
        }
    }
}
