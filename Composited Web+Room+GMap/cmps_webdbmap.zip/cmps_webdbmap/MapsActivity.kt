package kr.rndns.browseexhibition

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.View
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.GoogleMap.InfoWindowAdapter
import com.google.android.gms.maps.GoogleMap.OnPoiClickListener
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.*
import com.google.android.libraries.places.api.Places
import com.google.android.libraries.places.api.net.PlacesClient
import kr.rndns.browseexhibition.MapsActivity
import org.w3c.dom.Document
import org.w3c.dom.NodeList
import org.xml.sax.InputSource
import org.xml.sax.SAXException
import java.io.IOException
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.ArrayList
import java.util.function.Consumer
import javax.xml.parsers.DocumentBuilderFactory
import javax.xml.parsers.ParserConfigurationException
import javax.xml.xpath.XPathConstants
import javax.xml.xpath.XPathExpressionException
import javax.xml.xpath.XPathFactory

class MapsActivity : AppCompatActivity(), OnMapReadyCallback, OnPoiClickListener {
    private val TAG = MapsActivity::class.java.simpleName
    private val DEFAULT_ZOOM = 15
    private val PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION = 1
    private val KEY_CAMERA_POSITION = "camera_position"
    private val KEY_LOCATION = "location"

    var API_URL = "http://openapi.seoul.go.kr:8088/sample/xml/culturalSpaceInfo/1/5/"
    lateinit var thread: ConnectThread

    private var map: GoogleMap? = null
    private var cameraPosition: CameraPosition? = null
    private var placesClient: PlacesClient? = null
    private var fusedLocationProviderClient: FusedLocationProviderClient? = null
    private val defaultLocation = LatLng(-33.8523341, 151.2106085)
    private var locationPermissionGranted = false
    private var lastKnownLocation: Location? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState != null) {
            lastKnownLocation = savedInstanceState.getParcelable(KEY_LOCATION)
            cameraPosition = savedInstanceState.getParcelable(KEY_CAMERA_POSITION)
            Log.e(TAG, "[saved_maps_data] $lastKnownLocation $cameraPosition")
        }
        setContentView(R.layout.activity_maps)

        try {
            thread = ConnectThread(API_URL, this)
            thread.start()
        } catch (e: java.lang.Exception) {
            Toast.makeText(this, "Check your Internet", Toast.LENGTH_LONG)
        }

        Places.initialize(applicationContext, R.string.google_maps_key.toString())
        placesClient = Places.createClient(this)
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this)

        val mapFragment = supportFragmentManager
                .findFragmentById(R.id.map) as SupportMapFragment?
        mapFragment?.getMapAsync(this)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        if (map != null) {
            outState.putParcelable(KEY_CAMERA_POSITION, map!!.cameraPosition)
            outState.putParcelable(KEY_LOCATION, lastKnownLocation)
            Log.e(TAG, "[saving maps_data] $lastKnownLocation $cameraPosition")
        }
        super.onSaveInstanceState(outState)
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    override fun onMapReady(map: GoogleMap) {
        this.map = map

        // DB로 부터 데이터 가져와 찍기
        val db: ExhDatabase? = ExhDatabase.getInstance(this)
        val exhfaclist = db?.ExhFacilityDao()?.getAll()
        exhfaclist?.forEach(Consumer { (_, facName, addr, xCoord, yCoord, homepage) ->
            this.map!!.addMarker(MarkerOptions()
                    .position(LatLng(xCoord, yCoord))
                    .title(facName)
                    .snippet(" [주소]$addr [웹사이트]$homepage")
            )
        })

        this.map!!.setInfoWindowAdapter(object : InfoWindowAdapter {
            override fun getInfoWindow(arg0: Marker): View? {
                return null
            }

            override fun getInfoContents(marker: Marker): View {
                val infoWindow = layoutInflater.inflate(R.layout.custom_info_contents,
                        findViewById<View>(R.id.map) as FrameLayout, false)
                val title = infoWindow.findViewById<TextView>(R.id.title)
                title.text = marker.title
                val snippet = infoWindow.findViewById<TextView>(R.id.snippet)
                snippet.text = marker.snippet
                Log.e(TAG, "[UI info_window] " + title.text + " " + snippet.text)
                return infoWindow
            }
        })
        locationPermission()
        updateLocationUI()
        deviceLocation()
    }

    // Set the map's camera position to the current location of the device.
    private fun deviceLocation() {
        try {
            if (locationPermissionGranted) {
                val locationResult = fusedLocationProviderClient!!.lastLocation
                locationResult.addOnCompleteListener(this) { task ->
                    if (task.isSuccessful) {
                        // Set the map's camera position to the current location of the device.
                        lastKnownLocation = task.result
                        if (lastKnownLocation != null) {
                            map!!.moveCamera(CameraUpdateFactory.newLatLngZoom(
                                    LatLng(lastKnownLocation!!.latitude,
                                            lastKnownLocation!!.longitude), DEFAULT_ZOOM.toFloat()))
                        }
                        Log.e(TAG, "[set last_known_loc] $lastKnownLocation")
                    } else {
                        Log.e(TAG, "Current location is null. Using defaults.")
                        Log.e(TAG, "Exception: %s", task.exception)
                        map!!.moveCamera(CameraUpdateFactory
                                .newLatLngZoom(defaultLocation, DEFAULT_ZOOM.toFloat()))
                        map!!.uiSettings.isMyLocationButtonEnabled = false
                    }
                }
            }
        } catch (e: SecurityException) {
            Log.e("Exception: %s", e.message, e)
        }
    }

    private fun locationPermission() {
        if (ContextCompat.checkSelfPermission(this.applicationContext, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            locationPermissionGranted = true
        } else {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                    PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        locationPermissionGranted = false
        when (requestCode) {
            PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION -> {
                if (grantResults.size > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    locationPermissionGranted = true
                }
            }
        }
        updateLocationUI()
    }

    private fun updateLocationUI() {
        if (map == null) {
            return
        }
        try {
            if (locationPermissionGranted) {
                map!!.isMyLocationEnabled = true
                map!!.uiSettings.isMyLocationButtonEnabled = true
            } else {
                map!!.isMyLocationEnabled = false
                map!!.uiSettings.isMyLocationButtonEnabled = false
                lastKnownLocation = null
                locationPermission()
            }
        } catch (e: SecurityException) {
            Log.e("Exception: %s", e.message!!)
        }
    }

    override fun onPoiClick(pointOfInterest: PointOfInterest) {
        Toast.makeText(this, "Clicked: ${pointOfInterest.name} ${pointOfInterest.placeId}", Toast.LENGTH_LONG).show()
    }

    public class ConnectThread(var url_str: String, val context: Context) : Thread() {
        private val TAG = ConnectThread::class.java.simpleName
        var handler = Handler()
        lateinit var db: ExhDatabase

        @Throws(Exception::class)
        fun evaluateXPath(document: Document?, xpathExpression: String?): ArrayList<String> {
            val xpathFactory = XPathFactory.newInstance()
            val xpath = xpathFactory.newXPath()
            val values = ArrayList<String>()
            try {
                // xpathExpression에 해당하는 Node들 가져오기
                val expr = xpath.compile(xpathExpression)
                val nodes = expr.evaluate(document, XPathConstants.NODESET) as NodeList
                for (i in 0 until nodes.length) {
                    values.add(nodes.item(i).nodeValue)
                }
            } catch (e: XPathExpressionException) {
                Log.e(TAG, "XPathExpressionException occurred")
            }
            return values
        }

        override fun run() {
            // URL주소의 document 가져오기
            val xml = request(url_str)
            handler.post(Runnable {
                try {
                    // XPathExpression 작성하기
                    val num_exp = "/culturalSpaceInfo/row/NUM/text()"
                    val fac_exp = "/culturalSpaceInfo/row/FAC_NAME/text()"
                    val addr_exp = "/culturalSpaceInfo/row/ADDR/text()"
                    val x_exp = "/culturalSpaceInfo/row/X_COORD/text()"
                    val y_exp = "/culturalSpaceInfo/row/Y_COORD/text()"
                    val hp_exp = "/culturalSpaceInfo/row/HOMEPAGE/text()"

                    // document에서 XPath 가져오기
                    val nums = evaluateXPath(xml, num_exp)
                    val facs = evaluateXPath(xml, fac_exp)
                    val addrs = evaluateXPath(xml, addr_exp)
                    val xs = evaluateXPath(xml, x_exp)
                    val ys = evaluateXPath(xml, y_exp)
                    val homepages = evaluateXPath(xml, hp_exp)

                    db = ExhDatabase.getInstance(context)!!
                    Log.e(TAG, ""+db.isOpen)
                    for (i in nums.indices) {
                        var flag = db?.ExhFacilityDao()?.insert(ExhFacility(
                                nums[i].toInt(),
                                facs[i],
                                addrs[i],
                                xs[i].toDouble(),
                                ys[i].toDouble(),
                                homepages[i]
                        ))
                        Log.e(TAG, "[added exhfac from web] $flag")
                    }

                } catch (e: Exception) {
                    Log.e("Error_10001", "XPath failed", e)
                }
            })
        }

        fun request(url_str: String?): Document? {
            var outputDoc: Document? = null
            try {
                // HTTP로 URL주소 연결하기
                val url = URL(url_str)
                val conn = url.openConnection() as HttpURLConnection
                if (conn != null) {
                    conn.connectTimeout = 10000 // 10s이상이면 Timeout
                    conn.requestMethod = "GET"

                    // utf-8 인코딩으로 읽어오기
                    val isr = InputStreamReader(conn.inputStream, "utf-8")
                    val dbFactory = DocumentBuilderFactory.newInstance()
                    val builder = dbFactory.newDocumentBuilder()
                    outputDoc = builder.parse(InputSource(isr))
                    conn.disconnect()
                }
            } catch (e: IOException) {
                Log.e("Error_10001", "Exception in processing response", e)
            } catch (e: SAXException) {
                Log.e("Error_10001", "Exception in processing response", e)
            } catch (e: ParserConfigurationException) {
                Log.e("Error_10001", "Exception in processing response", e)
            }
            return outputDoc
        }
    }

}